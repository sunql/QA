#!/usr/bin/env bash
# 参数 VERSION BACKUP_DIR。仅在维护停写、备份恢复验证、迁移评审均已完成后执行。
set -euo pipefail
VERSION=${1:?VERSION required}
BACKUP_DIR=${2:?BACKUP_DIR required}
case "$VERSION" in ''|*[!A-Za-z0-9_.-]*) exit 1;; esac
BE="qa-system-backend:$VERSION"
FE="qa-system-frontend:$VERSION"
test -s "$BACKUP_DIR/metadata.dump"
test -s "$BACKUP_DIR/backend-image-id.txt"
test -s "$BACKUP_DIR/frontend-image-id.txt"
(cd "$BACKUP_DIR" && sha256sum -c metadata.dump.sha256)
for service in qa-backend qa-frontend; do
  test "$(docker inspect --format '{{.State.Running}}' "$service")" = false || {
    echo '前后端必须已停止并完成停写备份。'; exit 1;
  }
done
test "$(docker image inspect --format '{{.Os}}/{{.Architecture}}' "$BE")" = linux/amd64
test "$(docker image inspect --format '{{.Os}}/{{.Architecture}}' "$FE")" = linux/amd64
qa_compose() { docker-compose -p qa-system --env-file /opt/qa-system/docker/.env -f /opt/qa-system/docker/docker-compose.centos7.yml "$@"; }
qa_compose config --quiet
# 固定现有 Compose 镜像别名；不会修改 container_name。
docker tag "$BE" qa-backend:offline
docker tag "$FE" qa-system_frontend:latest
qa_compose up -d --no-build --no-deps --force-recreate backend
echo '后端已启动，正在执行启动期迁移。'
echo '立即查看 qa_compose logs -f --tail=150 backend。'
echo '确认启动、迁移与接口正常后，手工执行：'
echo 'qa_compose up -d --no-build --no-deps --force-recreate frontend'
echo '迁移失败时不要发布前端，不要盲目运行旧镜像。'

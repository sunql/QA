#!/usr/bin/env bash
# 有维护窗口后执行。会停止前后端；备份失败时保持停服，避免误发布。
set -euo pipefail
umask 077
COMPOSE_FILE=/opt/qa-system/docker/docker-compose.centos7.yml
qa_compose() { docker-compose -p qa-system --env-file /opt/qa-system/docker/.env -f "$COMPOSE_FILE" "$@"; }
qa_compose config --quiet
STAMP=$(TZ=Asia/Shanghai date +%Y%m%d-%H%M%S)
DIR="/opt/qa-backups/$STAMP"
mkdir -p "$DIR"
docker inspect --format '{{.Image}}' qa-backend > "$DIR/backend-image-id.txt"
docker inspect --format '{{.Image}}' qa-frontend > "$DIR/frontend-image-id.txt"
docker tag "$(cat "$DIR/backend-image-id.txt")" "qa-backend:pre-$STAMP"
docker tag "$(cat "$DIR/frontend-image-id.txt")" "qa-system_frontend:pre-$STAMP"
cp "$COMPOSE_FILE" "$DIR/docker-compose.centos7.yml"
cp /opt/qa-system/docker/.env "$DIR/production.env"
if [ -d /opt/qa-system/docker/certs ]; then cp -a /opt/qa-system/docker/certs "$DIR/backend-certs"; fi
# 必须另行暂停 docker exec 回填、定时任务、外部写入者；stop 不会替你协调外部任务。
qa_compose stop frontend backend
docker exec qa-postgres psql -U qa_user -d qa_metadata -v ON_ERROR_STOP=1 -tAc \
  'SELECT version_num FROM alembic_version ORDER BY version_num;' > "$DIR/alembic-before.txt"
docker exec qa-postgres pg_dump -U qa_user -d qa_metadata -Fc > "$DIR/metadata.dump.partial"
test -s "$DIR/metadata.dump.partial"
mv "$DIR/metadata.dump.partial" "$DIR/metadata.dump"
docker exec -i qa-postgres pg_restore --list < "$DIR/metadata.dump" > "$DIR/restore-list.txt"
cd "$DIR"
sha256sum metadata.dump > metadata.dump.sha256
echo "备份完成，前后端仍停止：$DIR"
echo '请完成隔离恢复验证及本次迁移专项预检，再发布。'

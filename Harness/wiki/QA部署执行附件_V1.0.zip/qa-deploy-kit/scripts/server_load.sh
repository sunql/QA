#!/usr/bin/env bash
# 在生产执行：bash scripts/server_load.sh VERSION，当前目录为上传的版本目录。
set -euo pipefail
VERSION=${1:?VERSION required}
case "$VERSION" in ''|*[!A-Za-z0-9_.-]*) exit 1;; esac
test "$(cat release-version.txt)" = "$VERSION"
sha256sum -c SHA256SUMS
BE="qa-system-backend:$VERSION"
FE="qa-system-frontend:$VERSION"
docker load -i "backend-$VERSION.tar.gz"
docker load -i "frontend-$VERSION.tar.gz"
for item in backend frontend; do
  image="qa-system-$item:$VERSION"
  actual=$(docker image inspect --format '{{.Id}}' "$image")
  test "$actual" = "$(cat "$item-image-id.txt")"
  test "$(docker image inspect --format '{{.Os}}/{{.Architecture}}' "$image")" = linux/amd64
done
# 仅复核已有后端容器采用的兼容策略；不修改 daemon 全局策略。
docker run --rm --network none --security-opt seccomp=unconfined \
  --entrypoint python "$BE" -c 'import threading; t=threading.Thread(target=lambda: print("THREAD_OK")); t.start(); t.join()'
docker run --rm --network none --security-opt seccomp=unconfined \
  --entrypoint alembic "$BE" heads
docker run --rm --network none --security-opt seccomp=unconfined \
  --entrypoint sh "$FE" -c 'printf "pid /run/nginx.pid;\nevents {}\n" > /tmp/nginx-check.conf; nginx -c /tmp/nginx-check.conf'
echo '导入和基础运行检查通过；尚未替换现役镜像标签或运行容器。'

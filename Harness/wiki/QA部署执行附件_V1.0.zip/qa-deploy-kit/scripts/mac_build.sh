#!/usr/bin/env bash
# 在 Mac 执行。参数：已同步的源码仓库绝对路径 发布版本号 [Git ref]
set -euo pipefail
REPO=${1:?Usage: mac_build.sh REPO VERSION [REF]}
VERSION=${2:?VERSION required}
REF=${3:-HEAD}
case "$VERSION" in ''|*[!A-Za-z0-9_.-]*) echo 'Invalid VERSION'; exit 1;; esac
REPO=$(cd "$REPO" && pwd)
KIT=$(cd "$(dirname "$0")/.." && pwd)
command -v python3 >/dev/null
docker buildx version
if [ -n "$(git -C "$REPO" status --porcelain)" ]; then
  echo '源码有未提交变更；请提交并确认版本后重试。'; exit 1
fi
COMMIT=$(git -C "$REPO" rev-parse "$REF^{commit}")
OUT="$(dirname "$REPO")/qa-releases/$VERSION"
[ ! -e "$OUT" ] || { echo "发布目录已存在：$OUT"; exit 1; }
mkdir -p "$OUT"
BUILD_ROOT=$(mktemp -d "${TMPDIR:-/tmp}/qa-build.XXXXXX")
cleanup() { git -C "$REPO" worktree remove --force "$BUILD_ROOT" >/dev/null 2>&1 || true; }
trap cleanup EXIT
git -C "$REPO" worktree add --detach "$BUILD_ROOT" "$COMMIT"
cd "$BUILD_ROOT"
test -f .dockerignore
BE="qa-system-backend:$VERSION"
FE="qa-system-frontend:$VERSION"
docker buildx build --platform linux/amd64 --provenance=false --sbom=false \
  --label "org.opencontainers.image.revision=$COMMIT" \
  --label "org.opencontainers.image.version=$VERSION" \
  -f docker/Dockerfile.backend -t "$BE" \
  --output "type=docker,dest=$OUT/backend-$VERSION.tar" .
docker buildx build --platform linux/amd64 --provenance=false --sbom=false \
  --label "org.opencontainers.image.revision=$COMMIT" \
  --label "org.opencontainers.image.version=$VERSION" \
  --build-arg VITE_API_BASE_URL=/api/v1 \
  -f docker/Dockerfile.frontend -t "$FE" \
  --output "type=docker,dest=$OUT/frontend-$VERSION.tar" .
python3 "$KIT/scripts/check_archive.py" "$OUT/backend-$VERSION.tar" "$BE" backend > "$OUT/backend-image-id.txt"
python3 "$KIT/scripts/check_archive.py" "$OUT/frontend-$VERSION.tar" "$FE" frontend > "$OUT/frontend-image-id.txt"
docker load -i "$OUT/backend-$VERSION.tar"
docker load -i "$OUT/frontend-$VERSION.tar"
# 真 .env 不得进入镜像；不执行应用 CMD，不接生产数据库。
docker run --rm --platform linux/amd64 --network none --entrypoint python "$BE" -c '
from pathlib import Path
found=[p for p in Path("/app").rglob(".env*") if not any(x in p.parts for x in (".venv","site-packages","node_modules"))]
bad=[str(p) for p in found if p.name != ".env.example"]
assert not bad, "Sensitive env files: " + repr(bad)
assert any(p.name == ".env.example" for p in found), "env example probe absent"
print("Backend env-file preflight PASS")'
docker run --rm --platform linux/amd64 --network none --entrypoint alembic "$BE" heads \
  > "$OUT/target-alembic-heads.txt"
test -s "$OUT/target-alembic-heads.txt"
printf '%s\n' "$COMMIT" > "$OUT/source-commit.txt"
printf '%s\n' "$VERSION" > "$OUT/release-version.txt"
cp -R "$KIT/scripts" "$KIT/sql" "$KIT/config" "$OUT/"
cp "$KIT/README.txt" "$OUT/"
gzip "$OUT/backend-$VERSION.tar"
gzip "$OUT/frontend-$VERSION.tar"
cd "$OUT"
find . -type f ! -name SHA256SUMS -exec shasum -a 256 {} \; > SHA256SUMS
echo "构建和静态检查完成：$OUT"
echo '仍需在 CentOS 7 进行运行兼容和隔离库迁移验证。'

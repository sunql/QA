-- 仅适用于从0132跨越数据域变更0133/0134的预检，不是每次发布通用检查。
\set ON_ERROR_STOP on
BEGIN READ ONLY;
SELECT code, name FROM business_object WHERE header_class_id IS NULL;
SELECT 'entity_mapping' AS check_item, count(*) AS count FROM entity_mapping
WHERE entity_type IN (SELECT code FROM business_object WHERE header_class_id IS NULL)
UNION ALL
SELECT 'feature_definition', count(*) FROM feature_definition
WHERE entity_type IN (SELECT code FROM business_object WHERE header_class_id IS NULL)
UNION ALL
SELECT 'document_entity_relation', count(*) FROM document_entity_relation
WHERE entity_type IN (SELECT code FROM business_object WHERE header_class_id IS NULL)
UNION ALL
SELECT 'feature_rule', count(*) FROM feature_rule
WHERE data_object IN (SELECT code FROM business_object WHERE header_class_id IS NULL);
COMMIT;
-- 任一 count>0：停止迁移，先由业务确认补绑或清理方案；此文件不会删除数据。

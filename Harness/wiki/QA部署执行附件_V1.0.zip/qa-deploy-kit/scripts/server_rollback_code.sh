#!/usr/bin/env bash
# 仅用于数据库版本未改变且应用/外部状态仍兼容的代码回滚。
# 参数：BACKUP_DIR。DDL回滚请按手册独立执行，禁止用此脚本替代数据库恢复。
set -euo pipefail
DIR=${1:?BACKUP_DIR required}
test -s "$DIR/alembic-before.txt"
NOW=$(mktemp)
trap 'rm -f "$NOW"' EXIT
docker exec qa-postgres psql -U qa_user -d qa_metadata -v ON_ERROR_STOP=1 -tAc \
  'SELECT version_num FROM alembic_version ORDER BY version_num;' > "$NOW"
cmp -s "$NOW" "$DIR/alembic-before.txt" || {
  echo '数据库版本已变化，拒绝仅回滚代码。请执行经评审的数据库回滚方案。'; exit 1;
}
qa_compose() { docker-compose -p qa-system --env-file /opt/qa-system/docker/.env -f /opt/qa-system/docker/docker-compose.centos7.yml "$@"; }
qa_compose stop frontend backend
docker tag "$(cat "$DIR/backend-image-id.txt")" qa-backend:offline
docker tag "$(cat "$DIR/frontend-image-id.txt")" qa-system_frontend:latest
qa_compose up -d --no-build --no-deps --force-recreate backend
echo '旧后端已启动；确认正常后再执行 qa_compose up -d --no-build --no-deps --force-recreate frontend。'

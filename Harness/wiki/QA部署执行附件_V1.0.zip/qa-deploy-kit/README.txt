QA系统开发到生产部署执行附件 V1.0 2026-10-29

适用：Mac arm64构建linux/amd64镜像；CentOS7.9 x86_64 Docker19.03.9 Compose1.29.2导入运行。
已部署生产的日常升级主流程：
1. Mac：bash scripts/mac_build.sh /Users/sunql/Prejectcode-th/MyWiki/wiki/aicode/qa-system 20261029-r01 HEAD
   必须是已提交且干净的源码。输出在仓库同级qa-releases/版本号。
   使用Docker archive exporter，避免多架构索引存在但amd64层缺失的save问题。
2. Mac：上传整个输出目录到生产 /opt/qa-releases/版本号；不要携带开发.env。
3. 生产：cd /opt/qa-releases/版本号；bash scripts/server_load.sh 版本号。
4. 完成维护窗口、暂停外部任务后，bash scripts/server_backup.sh。
   此脚本会停止前后端。记录打印的备份目录，执行手册中的隔离恢复验证和DDL专项预检。
5. 生产：bash scripts/server_activate.sh 版本号 /opt/qa-backups/实际备份时间。
   此脚本启动新后端，CMD会自动执行alembic upgrade head。必须已评审本次全部迁移。
6. 迁移/后端启动检查成功，qa_compose up -d --no-build --no-deps --force-recreate frontend。
7. 冒烟、向量生成与检索、本体入图并发响应、运行镜像ID核对；通过后恢复用户流量和后台任务。

qa_compose函数见Word手册或既有/root/.bashrc；新Shell运行source /root/.bashrc。
保留生产镜像别名qa-backend:offline、qa-system_frontend:latest，容器名不变。
server_rollback_code.sh只用于未变更数据库版本且状态兼容的代码回滚；DDL回滚另走手册。
0133_precheck.sql仅是历史0133/0134升级专项预检，count>0时不能继续。

脚本在本次编制中仅做语法与静态检查，未接入你的生产服务器执行。
SHA256SUMS校验的是文件完整性；发布来源和Git提交仍需人工核对。
禁止生产执行build、docker export/import替代save/load、down -v、直接删除/重建集合。
停止API可能终止docker exec运行的回填任务；需先确认完成或记录断点。
需要更多解释、首次安装、证书和数据库恢复步骤时，请使用配套Word手册。

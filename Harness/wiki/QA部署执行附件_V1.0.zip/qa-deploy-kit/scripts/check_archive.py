"""Validate Docker archive architecture and expected application tag; print config ID."""
import hashlib
import json
import sys
import tarfile

path, expected_tag, kind = sys.argv[1:]
with tarfile.open(path, "r:*") as archive:
    manifest = json.load(archive.extractfile("manifest.json"))
    matches = [entry for entry in manifest if expected_tag in (entry.get("RepoTags") or [])]
    if len(matches) != 1:
        raise SystemExit(f"Expected one {expected_tag} image, got {len(matches)}")
    raw = archive.extractfile(matches[0]["Config"]).read()
    config = json.loads(raw)
    if (config.get("os"), config.get("architecture")) != ("linux", "amd64"):
        raise SystemExit("Archive is not linux/amd64")
    command = " ".join(config.get("config", {}).get("Cmd") or [])
    if kind == "backend" and not all(word in command for word in ("alembic", "uvicorn")):
        raise SystemExit("Backend application CMD missing; may be a base image")
    print("sha256:" + hashlib.sha256(raw).hexdigest())
